# ClimatEnlighten — Messaging

## 1. The Audiences We Serve

Three individual audiences (B2C) and one organisational audience (B2B) split into two — Corporates and Educational Institutions — since a workforce decision and a curriculum decision are made differently, even though both are buying the same underlying value: more capable people. Five playbooks in total. None is ranked above another.

**Guardrail**
We will not try to be everywhere. For every audience, we choose one primary channel, one supporting channel, and one real-world touchpoint before adding another. If a channel isn't serving a defined audience, we don't create content for it.

**Universal, not audience-specific**
Never: fear campaigns, greenwashing, certificate-first marketing, overclaiming transformation. Core voice lines live in Brand — see there for "ignite a spark," "don't want to overwhelm you," and "concern should become action."

## 2. Audience Playbook

### B2C

#### Students (post-12th)

**Value proposition**
For students who have information but no direction, ClimatEnlighten offers reflection and real stories instead of more theory — so they leave with a next step they trust, not just more to read.

**Where they are**

*Online*
- LinkedIn — observed by Shiv; students actively connect with established professionals here and treat it seriously.
- Instagram Reels — a real attention channel, but only for content that doesn't feel like homework; boring educational content gets dismissed fast.
- Discord / Reddit — a future direction, not yet explored.

*Offline*
- Guest lectures through colleges — grounded in the founders' own experience running lectures and internships.
- Professor referrals — raised as an idea, not yet tried.

**Tone**
Curious. Conversational. Challenging after trust.

**Lead with**
Direction. Stories. Real journeys.

**Don't say**
Guaranteed jobs. Become a sustainability professional immediately. Endless theory.

**Trust comes from**
People who have lived career decisions themselves.

**Founder fit & proof**
Shiv opens with lived stories and urgency. Devraj deepens reflection and helps students place themselves. Proof: both founders left corporate careers themselves — we teach from lived experience.

---

#### Parents (pre-12th)

This segment is unvalidated — built from adjacent edtech experience, not direct research with parents. Treat its claims as directional, not confirmed.

**Value proposition**
For parents who need evidence before permission, ClimatEnlighten offers the mentorship neither founder had — consistent, integrity-led guidance instead of promises — so they can back this as a responsible choice for their child, not just a hopeful one.

**Where they are**

*Online*
- Individual WhatsApp — worked well within Shiv's own network; hard for people to ignore, though follow-through still varies.
- LinkedIn — effective, drawing on Shiv's long-built network.
- Webinars — suggested repeatedly, not yet run.

*Offline*
- School events / PTMs — a direction, not yet explored.

**Tone**
Reassuring. Responsible. Calm.

**Lead with**
Trust. Judgement. Responsible education.

**Don't say**
We'll transform your child. Guaranteed careers. Fear-based climate messaging.

**Trust comes from**
Integrity. Personal relationships. Consistency.

**Founder fit & proof**
Devraj's own path into sustainability had no mentor to guide it — that's both the story parents respond to and the proof behind it. Shiv's mentoring instinct, and the safe-space teaching philosophy, reinforce it.

---

#### Working Professionals

**Value proposition**
For professionals who want climate work without abandoning what they've built, ClimatEnlighten offers practical bridges instead of a leap of faith, built by founders who made that exact transition — so they can fold sustainability into their career instead of starting over.

**Where they are**

*Online*
- LinkedIn — a proven channel for this audience.
- Professional webinars — suggested indirectly, not yet tried.

*Offline*
- Offices — in-person touchpoints through workplace sessions.

**Tone**
Respectful. Reflective. Realistic.

**Lead with**
Bridges, not career abandonment.

**Don't say**
Quit your job. Start over.

**Trust comes from**
Founders who left corporate careers themselves.

**Founder fit & proof**
Shiv's transition. Devraj's reflective approach. Proof: both founders left corporate careers, bringing corporate sustainability leadership experience — practical grounding behind the teaching.

### B2B

#### 4a — Corporates

**Value proposition**
For companies that need training to build real workforce competence, not just satisfy an ESG checklist, ClimatEnlighten offers rigour and measurable outcomes instead of generic compliance content — so employees come out genuinely more capable.

**Where they are**

*Online*
- Email — institutions respond well to this channel.
- LinkedIn — reaches HR and L&D professionals directly.

*Offline*
- Offices — in-person workplace sessions with HR or L&D teams.

**Tone**
Professional. Outcome-focused. Efficient.

**Lead with**
Workforce capability. Measurable outcomes. Ease of collaboration.

**Don't say**
Generic CSR-speak. Compliance-only framing. Certificates without capability behind them.

**Trust comes from**
Rigour. Measurable outcomes. Ease of fitting into internal L&D processes.

**Founder fit & proof**
Both founders together, with corporate sustainability leadership experience carrying extra weight here. Proof: practical experience behind the teaching, not theory.

---

#### 4b — Educational Institutions

**Value proposition**
For institutions that need programmes to show real outcomes, not just inspire, ClimatEnlighten offers rigour and consistency instead of one-off talks — so they get a partner they can trust with their learners' actual outcomes.

**Where they are**

*Online*
- Email — institutions respond well to this channel.
- LinkedIn — reaches department heads and academic decision-makers.

*Offline*
- Guest lectures — already part of the founders' track record.
- Academic relationships — built from existing collaborations.

**Tone**
Structured. Credible. Practical.

**Lead with**
Engagement. Rigour. Ease of collaboration.

**Don't say**
Inspirational talks without outcomes.

**Trust comes from**
Preparation. Professional conduct. Consistency.

**Founder fit & proof**
Both founders together. Proof: WIOF's track record of sustaining communities, not just running events.

## 3. How We Tell A Story

Write every story using these four beats:
1. What was happening?
2. What were we or they stuck on?
3. What did we do differently?
4. What changed afterwards?

Make it sharp and captivating — a reader should want to know what happens next, not skim for the takeaway. Use specific, concrete detail over general claims; a story that could belong to any brand isn't finished. The learner is the hero throughout. ClimatEnlighten and the founders are never the hero.

## 4. How We Reuse Content

One meaningful conversation becomes many pieces of communication. The message adapts to the platform; the idea stays the same. We do not copy the same post across every channel.

Use this file to optimise distribution. For any story or piece of content, check which audience or audiences in Section 2 it actually serves, then use that persona's channels, tone, and value proposition — not a single format pushed everywhere.

## 5. Writing Standards — Avoid AI Tells

Every piece of writing gets checked against this before it's considered finished. If two or more of these appear, rewrite before publishing.

**Sentence structures to cut**
- "It's not X, it's Y" and "It's not just X, it's Y" — the contrast-reframe. State the real point plainly instead.
- "No A, no B, just C."
- A sentence padded with a present-participle clause at the end that adds no information ("...,creating lasting impact," "...,driving real change"). If the clause can be deleted without losing information, cut it.
- Reflexive rule-of-three lists ("clear, concise, and compelling"). Vary the count — two items, four items, whatever's actually true.
- Throat-clearing openers: "In today's fast-paced world," "In a world where," "Picture this."
- Self-announcing transitions: "Here's the thing," "Here's the kicker," "The best part?," "It's worth noting that."
- Robotic wrap-ups: "In summary," "In conclusion," or restating the opening point at the end.

**Words to flag on sight**
Delve, tapestry, mosaic, underscore, leverage (as a verb), multifaceted, complex interplay, moreover, furthermore, consequently, crucially, quietly, matters (as in "this matters"), earn (attached to anything abstract — "earn trust," "earn attention"), real/genuine used as an unearned intensifier, utilize (use "use"), facilitate (use "help").

**Other checks**
- Em-dashes: no more than one per paragraph, and only for a genuine interruption in thought — never as a stand-in for a comma or period.
- Hedge words (might, could, perhaps, generally, somewhat) — cut unless the uncertainty is real and relevant to the reader.
- Specificity test: every example should be concrete enough that it couldn't be swapped into a different brand's content unchanged. If it could, rewrite with something only ClimatEnlighten could say.
- Delete test: if a sentence can be removed and the paragraph loses no information, it was filler — cut it.
