# ClimatEnlighten — Audience

## Who We Speak To

We speak to people standing at the edge of a decision. They are not looking for more information — they are trying to decide whether this path is truly theirs. Each of them is navigating the distance between caring and committing, and that distance looks different depending on where they stand.

## B2C

### Segment 1 — Students (18+)

**Who they are**
Choosing a degree, a first career, or already studying sustainability — and still working out where they fit in it. At this age, the decision is theirs to make; parents have a say, not the final word.

**The real problem**
Information exists. Direction doesn't. They don't need motivation — they need permission to trust the path, and a next step that feels real rather than promised.

**Trust looks like**
Honest conversations. Real career journeys, uncertainty included. Questions before answers, reflection before advice.

**What they need from us**
Not another awareness session, not more theory, not certificates without direction. A large institution teaches subjects — we help them discover a direction.

**Where our story meets theirs**
We built ClimatEnlighten asking ourselves the same questions.

**We want them to feel**
"I don't have every answer, but I know my next step."

**Does NOT need**
Fear-based climate messaging. Career guarantees. Generic awareness talks. Certificates without direction.

### Segment 2 — Parents (of students under 18)

**Who they are**
Parents of students under 18, weighing subjects, streams, or a first direction on their child's behalf. At this age, the parent is the bigger stakeholder — the decision doesn't move without them, even when the child's curiosity does.

**The real problem**
They're not against sustainability. They're against risk without evidence. They need to believe this builds a livelihood, not just meaning, before they'll support it.

**Trust looks like**
Integrity over polish. Personal relationships, not campaigns. Consistency over time.

**What they need from us**
Not reassurance their child will be "transformed." Evidence this builds real judgement and a real future — for their specific child, not students in general.

**Where our story meets theirs**
Devraj built his own path into sustainability without a mentor to guide it. Climate is a field parents are starting to take seriously — but rarely know who to trust to guide their child through it. We're the mentorship neither founder had.

**We want them to feel**
"This is a responsible choice for my child, not just an inspiring one."

*Note: This segment is a hypothesis, not a researched finding — built from Abhishek's own edtech background as brand strategist, not from Shiv or Devraj speaking with actual parents. Sharpening it requires the founders to do that primary research themselves; treat this as provisional until they do.*

**Does NOT need**
Promises to "transform" their child. Guaranteed careers. Fear-based messaging.

### Segment 3 — Shekhar (Working Professionals)

**Who he is**
A working professional who wants sustainability to become part of his career — or part of how he works — even if he never fully switches.

**The real problem**
The financial, professional and emotional cost of changing direction feels too high.

**Trust looks like**
A safe place to ask basic questions without feeling behind. People who understand what it means to leave security.

**What he needs from us**
Practical bridges instead of motivational speeches. Context that connects his existing career with climate work.

**Where our story meets his**
Both founders left secure, accomplished careers themselves — this is where that story belongs. We've lived the transition.

**We want him to feel**
"I don't have to throw away my past to build my future."

**Does NOT need**
Pressure to quit immediately. Judgement for changing careers. One-size-fits-all roadmaps.

## B2B

### Segment 4 — Institutions & Organisations

**Shared thesis**
Sustainability isn't the destination — it's the spark that makes people more capable professionals. For a college, that shows up as employability. For a company, that shows up as workforce competence. One supplies the talent, the other employs it; the same underlying capability is what both are buying.

#### 4a — Corporates

**Who they are**
Companies upskilling employees in sustainability — driven by ESG/CSR obligations, or a genuine want for a sharper team. The decision sits with HR or an L&D/sustainability lead.

**The real problem**
Compliance training that checks a box doesn't make anyone better at their job. They need visibly more capable employees, not a certificate on file.

**Trust looks like**
Rigour. Measurable outcomes. Ease of fitting into internal L&D processes.

**What they need from us**
A workforce upskilling story, not a CSR tick-box exercise.

**Where our story meets theirs**
Both founders have led corporate sustainability work themselves — they know what actually builds capability, not just compliance.

**We want them to feel**
"Our people came out of this genuinely better at their jobs."

**Does NOT need**
Generic CSR-style compliance content. Certificates without a capability behind them.

#### 4b — Educational Institutions

**Who they are**
Colleges, universities, and departments preparing students for real careers, while balancing budgets and credibility. The decision sits with a professor or department head advocating internally.

**The real problem**
They cannot justify programmes that inspire but do not move outcomes like employability or placement.

**Trust looks like**
Consistency. Rigour. Fits inside the curriculum without extra administrative load.

**What they need from us**
Engagement, not information overload — outcomes that show up in how employable their students are.

**Where our story meets theirs**
We have seen what happens when education becomes a lecture instead of a story.

**We want them to feel**
"These are people we can trust with our learners' outcomes."

**Does NOT need**
Inspirational talks without measurable learning. Complex programmes that create extra administrative work.

## The One Learner

One person, standing in front of us, carrying all four of these at once.

Curious enough to ask a real question, but done with talks that ask for blind faith. Weighing a decision that isn't entirely theirs to make alone — someone else needs evidence, not promises, before they'll say yes. Unwilling to throw away what they've already built to chase something uncertain. Expecting rigour and follow-through, not just inspiration, before they'll give us their time.

They trust us when we're honest about what we don't know yet, consistent in how we show up, and specific about the next real step — not the whole plan.
