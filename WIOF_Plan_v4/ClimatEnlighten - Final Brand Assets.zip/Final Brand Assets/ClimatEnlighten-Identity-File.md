# ClimatEnlighten — Identity

## The Binding Thread

Climate action grows from trust, not from information.

The strongest pattern across everything ClimatEnlighten does is not sustainability itself — it is transformation through trust. Neither founder positions himself as an expert trying to impress people; both create the conditions for people to discover their own direction. Their leadership is unusually non-transactional: people stay because they feel seen, challenged, and trusted.

## Why ClimatEnlighten Exists

Climate education today is generic, overwhelming, intimidating, and often reduced to certificates, jobs, or greenwashing.

ClimatEnlighten exists because people need something different — a place that helps them think, question, connect, and act, not simply consume information. Not a set of knowledge to memorise and set aside. Not permission to settle for less than real understanding. A safe space to question. A catalyst to act.

## Personality

ClimatEnlighten is thoughtful before it is performative, and warm before it is impressive. It is rigorous without becoming academic, deeply hopeful without becoming naïve, and demanding without becoming intimidating.

It refuses to chase trends or compete for attention simply because everyone else is. It believes reflection is productive work, and treats questions as signs of curiosity, never weakness. It prefers conversation to preaching, and creates psychological safety without removing intellectual challenge.

It is rooted in Indian thought while remaining globally responsible. It believes climate change deserves urgency — but never paralysis.

## Values

**Foundational**
- Planet before profession.
- Curiosity over anxiety.
- Learning toward fulfilment.
- Safe spaces create better learners.
- Reflection matters.

**Operational**
- Story before information.
- Reflection before advice.
- Challenge ideas, never people.
- Concern should lead to action.

**Aspirational**
- Ignite sparks rather than manufacture transformation.
- Help people discover their own place in sustainability.
- Build education that people trust.

## The NOT List

ClimatEnlighten is not:
- Competitive.
- Boring.
- Just another generic sustainability course.
- A certificate.
- A job guarantee.
- A quick fix.

## The Two Founders

**Shiv**
Before ClimatEnlighten, Shiv left a corporate career, like Devraj, to work on sustainability full time. For ten years he has composted every gram of his own household's wet waste, and his housing society of 282 flats now asks him to run sessions on it. Proof before pitch.

Shiv builds environments where people feel safe enough to grow. His instinct is mentorship. Sustainability shaped him into someone who believes character matters before competence. His recurring pattern is creating communities where ordinary people become capable through trust.

**Devraj**
Devraj studied information technology and spent three to four years at Infosys, where he first met Shiv. In 2020 he left to pursue a master's in Environmental Science at MSU Baroda. His dissertation researched eco-psychology — why people outside the sustainability field become curious enough to connect with nature and act on it. WIOF was built alongside Shiv during this period.

Devraj asks questions before giving answers. His instinct is reflection. Eco-psychology shaped him into someone who believes lasting change comes from self-awareness rather than information. He naturally connects ideas, people and purpose.

**Together**
Shiv creates momentum.
Devraj creates meaning.
Together they create direction.
The venture exists because one founder lights the spark while the other helps people understand why it matters.

## WIOF vs ClimatEnlighten

World Is One Family is the movement: it asks *"why should I care?"* and builds consciousness, community, and worldview. ClimatEnlighten is the education venture born from it: it asks *"what do I do now?"* and builds the capability to act.

WIOF is the mission. ClimatEnlighten is the revenue that sustains it. Each supports the other — neither replaces it.

## Only ClimatEnlighten

Only ClimatEnlighten creates a safe space where curiosity becomes climate action.

## The Tensions

**Urgency vs Hope**
Concern → Reflection → Agency → Action.

**Rigour vs Safe Space**
Keep standards high, and remove fear from learning.

## The Dot Connection

ClimatEnlighten creates a safe space where people encounter meaningful climate knowledge without being overwhelmed — where curiosity is awakened, reflection is encouraged, and people begin discovering how sustainability fits into their own lives. It does not claim to transform people. It ignites a spark. The learner owns the journey that follows.
