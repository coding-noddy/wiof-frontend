# ClimatEnlighten — Brand

## About This File

This file covers how ClimatEnlighten's identity is expressed outwardly: positioning, voice, logo, and the visual system. Values, personality, and the founders' full story live in Identity.

## Positioning

ClimatEnlighten is the education venture built on curiosity instead of consumption. Climate education today is generic, overwhelming, and reduced to certificates, jobs, and greenwashing — more information, when what people actually need is direction. ClimatEnlighten builds that direction through reflection and a safe space to ask real questions. We don't manufacture transformation. We ignite the spark, and let the learner own the journey that follows.

## Voice

**Descriptors:** Thoughtful. Grounded. Honest. Encouraging. Quietly challenging.

**Representative lines**
- "We don't want to overwhelm you."
- "We just want to ignite a spark."
- "Concern should become action."
- "You don't need every answer before taking the next step."

**Founder registers**
Shiv speaks through urgency, examples, and movement. Devraj speaks through reflection, questions, and psychology. The shared voice that emerges from both is calm, hopeful, intellectually honest, and practical.

## Logo

**ClimatEnlighten**
A desktop globe and a rising sun combine into a single monogram, reading Climat + Enlighten as one mark. The globe stands for the classroom, for education, deliberately not the usual book. Its stand forms the C. Behind the earth, the sun looms and rises, enlightening it, and its rays form the E. Wordmark in Ocean Teal, set in Aleo, with "Simplifying Climate Education" beneath it in brown.

**WIOF**
The exact same mark WIOF has carried for six years — only the colour has changed. It used to run as a brown gradient with a grey wordmark: a single shade of brown said the right thing but read as one-dimensional. Earthy Brown stays as the base, and Ocean Teal and Sunny Marigold have been added, each now carrying its own piece of brand meaning rather than sitting there as decoration. The gradient has become a flat fill: gradient reads soft, dimensional, almost glossy, which sits against the flat, graphic language the rest of the identity uses, so flat colour is the more honest, more modern choice. The wordmark is reset in Aleo, the same face as ClimatEnlighten, in a more balanced, symmetrical layout that narrows evenly on both sides.

**Typography**
Display: Aleo
Body: Noto Sans

## Visual System

### Purpose

This is the visual brief for all ClimatEnlighten brand visuals.

The system must work consistently across **all physical and digital brand assets**.

It defines a visual grammar, not a collection of motifs that must appear in every asset.

**The subject and idea come first. The visual language supports them.**

### 1. The Core Visual Idea

ClimatEnlighten is about **something becoming clearer**.

The visual world should express:

- understanding
- discovery
- perspective
- possibility
- awareness becoming meaningful

The visual question is:

> **What is becoming clearer here?**

This can be expressed through light, revelation, overlap, contrast, direction, scale or a change in visual relationships.

There is no requirement to show a literal source of light.

**Illumination is a visual behaviour, not a recurring object.**

### 2. The Visual Hierarchy

Every visual should begin with:

**IDEA → SUBJECT → COMPOSITION → VISUAL LANGUAGE**

Not:

**LOGO MOTIF → DECORATION → CONTENT**

The elemental patterns and illumination language are a vocabulary to draw from when they strengthen the idea.

They are **not a set of brand decorations to fill empty space**.

A visual may use:

- no elemental pattern
- one elemental language
- a combination of two or more

Use only what the concept needs.

### 3. Illumination

Illumination is expressed primarily through **rays, revelation and interaction**.

#### Rays

The ClimatEnlighten logo's rays are an important reference.

They are **graphic rays of illumination**, not necessarily rays belonging to a visible sun.

They can:

- emerge from an edge
- enter from outside the frame
- originate behind an object
- fall across a landscape
- pass behind or between living things
- highlight a particular area
- reveal a path, object, idea or relationship
- exist as an abstract graphic field

The rays may therefore appear **without any sun at all**.

Their job is to create a sense that something is being lit, revealed or brought into focus.

The rays should remain bold and graphic, with the same visual weight as the logo.

#### The Sun

A literal sun is an **occasional environmental subject**, not a primary brand motif.

When a scene genuinely calls for a sun, it should usually be:

- partially visible
- behind something
- near an edge
- small relative to the scene
- subordinate to the landscape or subject

The logo is the reference: the sun **peeks**, while the rays do the visual work.

The sun does not need to appear whenever rays are used.

### 4. Illustration Language

Illustrations should be:

- Flat
- Graphic
- Organic
- Simple
- Contemporary
- Layered
- Expressive

Use solid fills, bold graphic linework, simple shapes and controlled detail.

The style should feel **designed, not painted**.

#### Living things

The same language applies to the wider living world:

- people
- animals
- birds
- plants
- insects
- marine life
- other living organisms

Living things should be simplified into recognisable shapes, silhouettes and gestures.

They do not require realistic rendering.

They should feel like **participants in the world**, not decorative symbols for "nature".

### 5. Line & Stroke Language

All graphic and elemental linework should have a **bold, consistent stroke weight comparable to the strokes in the ClimatEnlighten and WIOF logos**.

This is part of the identity.

The linework should feel:

**bold + clean + graphic + deliberate**

The patterns should look as though they belong beside the logos.

They should not become thin, delicate, wispy, sketch-like or painterly.

The same stroke logic applies to:

- elemental patterns
- rays
- illustrative outlines
- icons
- small graphic details

### 6. The Five Elements

The five elements provide a **visual vocabulary**, not five motifs to distribute across every design.

**When land, water or open air are already part of a scene, render them in this vocabulary.** A hillside, a lake or a sky is not neutral background, it is an opportunity to carry the brand's line language. Rays alone do not cover a landscape: if the scene has ground, give it terrain lines; if it has water, give it wave lines; if it has open sky or air, let wind lines move through it. Selectivity governs which elements to introduce into a scene that doesn't already call for them, not whether to render land, water or air that's already there.

#### Earth — Terrain

Bold contour-like lines that describe land, terrain and layers.

In a landscape, they run along the ground plane: hills, ridgelines, fields, riverbanks, the base of the scene.

Use when the concept relates to:

- land
- place
- landscape
- grounding
- geological or ecological systems

#### Water — Waves

Bold flowing curves and wave forms.

In a landscape, they describe the surface of whatever water is present: a lake, river, coastline or any other body of water in the scene.

Use when the concept relates to:

- water
- flow
- cycles
- movement
- changing systems

#### Air — Wind

Bold directional strokes that move through space.

In a landscape, they move through the open sky or negative space above the ground, suggesting breeze, weather or atmosphere.

Use when the concept relates to:

- air
- atmosphere
- movement
- direction
- transition

#### Energy — Rays

Bold rays emerging from a point or entering a composition.

Use when the concept relates to:

- energy
- illumination
- revelation
- activation
- something becoming visible

**Energy is the ray language. It is not a requirement to draw a sun.**

#### Spirit — Concentric Circles

Bold concentric circles representing expansion, reflection, depth or inward attention.

They should be **anchored to the idea they represent**.

For example, they may surround or emerge from:

- a person
- an interaction
- an idea
- a point of reflection
- an area of focus
- an expanding influence

They should not be introduced simply because there is unused space.

**Spirit is a contextual visual device, not a background texture.**

### 7. Pattern Behaviour

Patterns should behave like **part of the world or the idea**, not like wallpaper.

They can:

- form a landscape
- describe movement
- frame a subject
- reveal a system
- interact with an illustration
- lead the eye
- create visual rhythm
- become part of an object

They should have a relationship with something in the composition.

#### Default rule

**If removing the pattern does not change the meaning or visual logic of the composition, the pattern probably does not belong there.**

### 8. Colour

The core three colours are fixed.

| Role | Colour | Hex |
|---|---|---|
| Primary | Earthy Brown | `#A6875D` |
| Secondary | Ocean Teal | `#21999F` |
| Accent | Sunny Marigold | `#FFC26F` |

#### Approved tints and shades

| Colour | Tint 40% | Tint 20% | Base | Shade 20% | Shade 40% |
|---|---|---|---|---|---|
| Earthy Brown | `#CAB79E` | `#B89F7D` | `#A6875D` | `#856C4A` | `#645138` |
| Ocean Teal | `#7AC2C5` | `#4DADB2` | `#21999F` | `#1A7A7F` | `#145C5F` |
| Sunny Marigold | `#FFDAA9` | `#FFCE8C` | `#FFC26F` | `#CC9B59` | `#997443` |

#### Neutrals

| Role | Colour | Hex |
|---|---|---|
| Light background | Ivory | `#FAF5EC` |
| Card / box surfaces | Warm White | `#FFFCF6` |
| Secondary text / borders | Warm mid-grey | `#A69C8E` |
| Primary text / ink | Warm near-black | `#2B2420` |

The palette should feel **earthy, warm and luminous**.

Earthy Brown grounds.

Ocean Teal carries the identity.

Sunny Marigold provides warmth and illumination.

Ivory gives the system space.

Warm White lifts card and box surfaces off the page without going flat white.

Use the approved tonal range for depth rather than introducing unrelated colours.

### 9. Composition

The system does not prescribe a single composition.

It can be:

- minimal or rich
- symmetrical or asymmetrical
- abstract or narrative
- close or environmental
- quiet or energetic

But every composition should have a **clear focal idea**.

Do not begin with a collection of motifs and then place content inside them.

Begin with the content.

Then decide whether a ray, terrain line, wave, wind line or concentric form genuinely strengthens it.

### 10. Do / Don't

#### DO

- Start with the idea being communicated.
- Use illumination as a behaviour rather than an object.
- Let rays exist independently of a visible sun.
- Let rays interact with the environment or subject.
- Keep a literal sun secondary when it is used.
- Use elemental patterns selectively.
- Make patterns belong to the scene or concept.
- Keep all linework bold and consistent with the logos.
- Use flat, graphic representations of living things.
- Use the approved palette and tonal range.
- Give the creator freedom to interpret the system.

#### DON'T

- Treat the sun as the default symbol of ClimatEnlighten.
- Add a sun simply because rays are being used.
- Make a large sun the focal point unless the subject specifically requires it.
- Use concentric circles as generic background decoration.
- Add an elemental pattern just to fill empty space.
- Treat the five elements as a checklist.
- Use thin or painterly linework.
- Turn patterns into decorative textures.
- Make every visual look like the same landscape scene.
- Make everything green.
- Use generic environmental clichés.
- Use arbitrary colours outside the palette.
- Default to photorealism, 3D or glossy rendering.
- Make living things realistic while the rest of the illustration remains flat.

### 11. The Test

Before approving a visual, ask:

**What is the idea?**

**What is becoming clearer?**

**Does every graphic element support that idea?**

**If rays are present, what are they doing?**

**If a sun is present, is it part of the scene rather than the brand motif?**

**If concentric circles are present, what do they represent?**

**Are the elemental forms interacting meaningfully with the scene or with one another?**

**Does the linework feel like it belongs to the ClimatEnlighten and WIOF logos?**

If yes, the visual belongs to the system.

### 12. Overall Feeling

**Climate education that illuminates.**

Warm.

Thoughtful.

Graphic.

Living.

Luminous.

A visual world where **ideas become clearer, light reveals rather than decorates, and natural forms support meaning rather than become decoration.**
